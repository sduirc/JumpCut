
#ifndef _FF_IPF_DEF_H
#define _FF_IPF_DEF_H

#include"ffdef.h"

#define _IPF_API

#define _IPF_BEG _FF_BEG

#define _IPF_END _FF_END


#endif

