
#ifndef _FF_IPF_IPT_FUNC_H
#define _FF_IPF_IPT_FUNC_H

#ifndef _FF_IPF_IPT_H
#include"ipf/ipt.h"
#endif


_IPF_BEG







_IPF_END



#endif

