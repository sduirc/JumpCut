
#ifndef _FF_BFC_DEF_H
#define _FF_BFC_DEF_H


#include"ffdef.h"


#define _FF_BEG _FF_BEG

#define _FF_END _FF_END

#endif

