
#ifndef _FF_FFS_CFG_H
#define _FF_FFS_CFG_H


#ifndef new

#ifdef _DEBUG

#include"bfc\mem.h"

#define new FF_DEBUG_NEW

#endif

#endif

#endif

