
#include<memory.h>
#include<algorithm>

#include"fpm.h"

#include"fftw3.h"

#include"fpmi.h"

typedef fftwf_complex  cdata_t;

#include"fvtif.h"

#include FVT_FITYPE_H
#include FVT_FIUTIL_H
#include FVT_FICORE_H

using namespace fvt;


struct fft_data
{
	fftwf_plan p1,p2;
	cdata_t *parr;

	float    *pin;
	cdata_t  *pout;
	
	int		 w,W,h,H;
};

fft_data* fft_create(int w, int W, int h, int H, float *pin, cdata_t *pout)
{
	fft_data *pfft=new fft_data;
	memset(pfft,0,sizeof(*pfft));

	pfft->parr=(cdata_t*)fftwf_malloc(W*H*sizeof(cdata_t));
	memset(pfft->parr,0,W*H*sizeof(cdata_t));

//	pfft->p1=fftwf_plan_dft_1d(1<<N1,pfft->pin,pfft->pcol,FFTW_FORWARD,FFTW_MEASURE|FFTW_PRESERVE_INPUT);

	int n1[]={H,w};

	pfft->p1=fftwf_plan_many_dft_r2c(1,n1,w,pin,NULL,1,H,pfft->parr,NULL,W,1,FFTW_MEASURE|FFTW_PRESERVE_INPUT);

	int n2[]={W,H};

	pfft->p2=fftwf_plan_many_dft(1,n2,H,pfft->parr,NULL,1,W,pout,NULL,1,W,FFTW_FORWARD,FFTW_MEASURE|FFTW_PRESERVE_INPUT);

	return pfft;
}

void fft_free(fft_data *pfft)
{
	if(pfft)
	{
		fftwf_destroy_plan(pfft->p1);
		fftwf_destroy_plan(pfft->p2);

		fftwf_free(pfft->parr);

		delete pfft;
	}
}


void fft_exec(fft_data *pfft)
{
	fftwf_execute(pfft->p1);

	fftwf_execute(pfft->p2);
}

class pat_fft
{
public:
	fft_data *m_pat_fft;
	float    *m_pat_in;
	cdata_t  *m_pat_out;

	int m_w,m_W,m_h,m_H;
public:

	pat_fft()
	{
		memset(this,0,sizeof(*this));
	}

	~pat_fft()
	{
		fft_free(m_pat_fft);
		fftwf_free(m_pat_in);
		fftwf_free(m_pat_out);
	}

	void reset(int w,int W,int h,int H)
	{
		m_pat_in=(float*)fftwf_malloc(sizeof(float)*w*H);
		memset(m_pat_in,0,sizeof(float)*w*H);

		m_pat_out=(cdata_t*)fftwf_malloc(sizeof(cdata_t)*W*H);

		m_pat_fft=fft_create(w,W,h,H,m_pat_in,m_pat_out);

		m_w=w, m_h=h, m_W=W, m_H=H;
	}

	const cdata_t* exec(const void *pat, int step, int stride, int type)
	{
		fpm_cvt_data(pat, m_h, m_w, step, stride, type, m_pat_in, sizeof(float)*m_H, sizeof(float), FPMT_32F);

		fft_exec(m_pat_fft);

		return m_pat_out;
	}
};

class img_fft
{
public:
	fftwf_plan m_plan;

	float     *m_in;
	cdata_t   *m_out;

	int        m_width, m_height;

public:
	img_fft()
	{
		memset(this,0,sizeof(*this));
	}
	~img_fft()
	{
		fftwf_destroy_plan(m_plan);

		fftwf_free(m_in);
		fftwf_free(m_out);
	}
	void reset(int width,int height)
	{
		m_in=(float*)fftwf_malloc(width*height*sizeof(float));
		m_out=(cdata_t*)fftwf_malloc(width*height*sizeof(cdata_t));

		m_plan=fftwf_plan_dft_r2c_2d(width,height,m_in,m_out,FFTW_FORWARD);

		m_width=width; m_height=height;
	}
	const cdata_t* exec(const void *pat, int step, int stride, int type)
	{
		fpm_cvt_data(pat,m_width,m_height,step,stride,type,m_in,sizeof(float)*m_width,sizeof(float),FPMT_32F);

		fftwf_execute(m_plan);

		return m_out;
	}
};

class img_rfft
{
public:
	fftwf_plan m_plan;

	cdata_t     *m_in;
	float       *m_out;

	int        m_width, m_height;

public:
	img_rfft()
	{
		memset(this,0,sizeof(*this));
	}
	~img_rfft()
	{
		fftwf_destroy_plan(m_plan);

		fftwf_free(m_in);
		fftwf_free(m_out);
	}
	void reset(int width,int height)
	{
		m_in=(cdata_t*)fftwf_malloc(width*height*sizeof(cdata_t));
		m_out=(float*)fftwf_malloc(width*height*sizeof(float));

		m_plan=fftwf_plan_dft_c2r_2d(width,height,m_in,m_out,FFTW_BACKWARD);

		m_width=width; m_height=height;
	}
	cdata_t* in_buf() const
	{
		return m_in;
	}
	const float* exec()
	{
		fftwf_execute(m_plan);

		return m_out;
	}
};

static void _calc_spec_conv(const float *pws, const float *pi2s, const float *pps, const float *pis, float *pdest, int count)
{
	float scale=1.0f/count;

	for(int i=0;i<count;++i,pws+=2,pi2s+=2,pps+=2,pis+=2,pdest+=2)
	{
		pdest[0]=(pws[0]*pi2s[0]+pws[1]*pi2s[1]-pps[0]*pis[0]-pps[1]*pis[1]);

		pdest[1]=(pws[0]*pi2s[1]-pws[1]*pi2s[0]-pps[0]*pi2s[1]+pps[1]*pis[0]);

	//	pdest[0]=scale*(double(pws[0])*pi2s[0]+pws[1]*pi2s[1]-pps[0]*pis[0]-pps[1]*pis[1]);

	//	pdest[1]=scale*(double(pws[0])*pi2s[1]-pws[1]*pi2s[0]-pps[0]*pi2s[1]+pps[1]*pis[0]);

	}
}

class FFT_FPM::_CImp
{
	pat_fft  m_pfft, m_wfft;
	img_fft  m_ifft;
	img_rfft m_rfft;

	int		 m_iw,m_ih,m_pw,m_ph, m_flag;
	float    m_sel;

	FVTImage m_ispec, m_i2spec;

	FVTImage m_i2int;

	FVTImage m_mask;

	std::vector<float>  m_wpat;

public:
	void Plan(int iwidth, int iheight, int pwidth, int pheight, int flag, float sel)
	{
		m_pfft.reset(pwidth,iwidth,pheight,iheight);

		m_ifft.reset(iwidth,iheight);

		m_rfft.reset(iwidth,iheight);

		if(flag&FPMF_WEIGHTED)
			m_wfft.reset(pwidth,iwidth,pheight,iheight);

		m_iw=iwidth,m_ih=iheight,m_pw=pwidth,m_ph=pheight, m_flag=flag;
		m_sel=sel<1.0f? 1.0f:sel;

		m_wpat.resize(m_pw*m_ph);
	}

	void SetImage(const void *img, int istep,int istride, int itype, const unsigned char *mask, int mstep)
	{
		FVTImage ix(m_iw,m_ih,FI_32FC1),ix2(m_iw,m_ih,FI_32FC1);

		fpm_cvt_data(img,m_iw,m_ih,istep,istride,itype,FI_AL_DS(ix),sizeof(float),FPMT_32F);

		float scale=1.0f/(m_iw*m_ih);

		{
			fiuForPixels_1_1(FI_AL_DWHSP_AS(ix,float),FI_AL_DSP_AS(ix2,float),IOPScale<1,float>(2.0f*sqrt(scale)));
			
			const cdata_t *pres=m_ifft.exec(ix2.Data(),ix2.Step(),ix2.PixelSize(),FPMT_32F);

			m_ispec.Reset(m_iw,m_ih,FI_32FC2,sizeof(float));
			fiuCopy(pres,sizeof(cdata_t)*m_iw,m_ih,sizeof(cdata_t)*m_iw,FI_AL_DS(m_ispec));
		}

		if(m_flag&FPMF_WEIGHTED)
		{
			fiuForPixels_2_1(FI_AL_DWHSP_AS(ix,float),FI_AL_DSP_AS(ix,float),FI_AL_DSP_AS(ix2,float),IOPMul<1>()); //calc square

			fiuForPixels_0_1(FI_AL_DWHSP_AS(ix2,float),InplaceI0(IOPScale<1,float>(scale)));

			const cdata_t *pres=m_ifft.exec(ix2.Data(),ix2.Step(),ix2.PixelSize(),FPMT_32F);

			m_i2spec.Reset(m_iw,m_ih,FI_32FC2,sizeof(float));
			fiuCopy(pres,sizeof(cdata_t)*m_iw,m_ih,sizeof(cdata_t)*m_iw,FI_AL_DS(m_i2spec));
		}
		else
		{
			//else integrate i^2, not implemented yet!
		}

//		m_rspec.Reset(m_iw,m_ih,FI_32FC2,sizeof(float));

		if(mask)
		{
			m_mask.Reset(m_iw,m_ih,FI_8UC1,1);

			assert(m_mask.Step()==m_iw);

			fiuCopy(mask,m_iw,m_ih,mstep,FI_AL_DS(m_mask));
		}
	}

	const float *GetSSD(const void *pat, int pstep, int pstride, int ptype, const float *weight, int flag)
	{
		float dssd=0;

		fpm_cvt_data(pat,m_pw,m_ph,pstep,pstride,ptype,&m_wpat[0],sizeof(float)*m_pw,sizeof(float),FPMT_32F);

		int np=m_pw*m_ph;

		if(flag&FPMF_TRUE_SSD)
		{
			for(int i=0;i<np;++i)
				dssd+=m_wpat[i]*m_wpat[i];
		}

		float scale=sqrt(1.0f/(m_iw*m_ih));

		for(int i=0;i<np;++i)
			m_wpat[i]*=weight[i]*scale;

		const cdata_t *ppspec=m_pfft.exec(&m_wpat[0],sizeof(float)*m_pw,sizeof(float),FPMT_32F);
		const float   *pwssd=NULL;

		if(m_flag&FPMF_WEIGHTED)
		{
			assert(weight);

			const cdata_t *pwspec=m_wfft.exec(weight,sizeof(float)*m_pw,sizeof(float),FPMT_32F);

			_calc_spec_conv((float*)pwspec,m_i2spec.DataAs<float>(),(float*)ppspec,m_ispec.DataAs<float>(),(float*)m_rfft.in_buf(),m_iw*m_ih);

			pwssd=m_rfft.exec();
		}
		else
		{
			//...
		}

		if(dssd!=0)
		{
			np=m_iw*m_ih;
			float *pssdx=(float*)pwssd;

			for(int i=0;i<np;++i)
				pssdx[i]+=dssd;
		}

		return pwssd;
	}

	int Match(const void *pat, int pstep, int pstride, int ptype, const float *weight, int *pmatch,int nmax)
	{
		const float *pssd=this->GetSSD(pat,pstep,pstride,ptype,weight,FPMF_TRUE_SSD);

		return fpm_ssd_select(pssd,m_mask.Data(),m_iw*m_ih,pmatch,nmax,m_sel);
	}
};


//====================================================================================================================

FFT_FPM::FFT_FPM()
:m_pImp(new _CImp)
{
}

FFT_FPM::~FFT_FPM()
{
	delete m_pImp;
}

const float *FFT_FPM::GetSSD(const void *pat, int pstep, int pstride, int ptype, const float *weight, int flag)
{
	return m_pImp->GetSSD(pat,pstep,pstride,ptype,weight,flag);
}

void FFT_FPM::Plan(int iwidth, int iheight, int pwidth, int pheight, int flag, float sel)
{
	m_pImp->Plan(iwidth,iheight,pwidth,pheight,flag,sel);
}

void FFT_FPM::SetImage(const void *img, int istep, int istride, int itype, const unsigned char *mask, int mstep)
{
	m_pImp->SetImage(img,istep,istride,itype,mask,mstep);
}

int FFT_FPM::Match(const void *pat, int pstep, int pstride, int ptype, const float *weight, int *pmatch,int nmax)
{
	return m_pImp->Match(pat,pstep,pstride,ptype,weight,pmatch,nmax);
}







